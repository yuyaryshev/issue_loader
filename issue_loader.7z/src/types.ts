
export interface JiraIssue {
  [key:string]: any;
};
